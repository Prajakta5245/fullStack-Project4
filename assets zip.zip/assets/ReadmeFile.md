# Project 4
 ## **Live link:** **[Project 4](https://ornate-entremet-bb903c.netlify.app/)**

## Skills
- I learn how to use positionning.
- i learn about font Differnt styles and font decoration properties.


## Time taken to Complete:
- It is lit bit easy but i am learning new  thing. Some concept are new for me so it took more time to understand the concept it takes 10Hr to complete this website.
  


